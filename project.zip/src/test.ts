require('dotenv').config({ path: '.env.development' })

console.log(process.env.DAIN_API_KEY)